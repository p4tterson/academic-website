---
abstract: Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis posuere tellus
  ac convallis placerat. Proin tincidunt magna sed ex sollicitudin condimentum. Sed
  ac faucibus dolor, scelerisque sollicitudin nisi. Cras purus urna, suscipit quis
  sapien eu, pulvinar tempor diam. Quisque risus orci, mollis id ante sit amet, gravida
  egestas nisl. Sed ac tempus magna. Proin in dui enim. Donec condimentum, sem id
  dapibus fringilla, tellus enim condimentum arcu, nec volutpat est felis vel metus.
  Vestibulum sit amet erat at nulla eleifend gravida.
authors:
- admin
- Robert Ford
date: "2015-09-01T00:00:00Z"
doi: ""
featured: false
image:
  caption: 'Image credit: [**Unsplash**](https://unsplash.com/photos/jdD8gXaTZsc)'
  focal_point: ""
  preview_only: false
projects: []
publication: '*Journal of Source Themes, 1*(1)'
publication_short: ""
publication_types:
- "2"
publishDate: "2017-01-01T00:00:00Z"
slides: example
summary: Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis posuere tellus
  ac convallis placerat. Proin tincidunt magna sed ex sollicitudin condimentum.
tags:
- Source Themes
title: An example journal article
url_code: ""
url_dataset: ""
url_pdf: http://arxiv.org/pdf/1512.04133v1
url_poster: ""
url_project: ""
url_slides: ""
url_source: ""
url_video: ""
---

{{% alert note %}}
Click the *Cite* button above to demo the feature to enable visitors to import publication metadata into their reference management software.
{{% /alert %}}

{{% alert note %}}
Click the *Slides* button above to demo Academic's Markdown slides feature.
{{% /alert %}}

Supplementary notes can be added here, including [code and math](https://sourcethemes.com/academic/docs/writing-markdown-latex/).
